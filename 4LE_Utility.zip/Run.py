from Model import *
from Controller import *
from View import *

#Check Connections

#Check for Updates to application

#Run the main screen

