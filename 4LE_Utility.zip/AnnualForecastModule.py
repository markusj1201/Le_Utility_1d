import sys
sys.path.append('../')

""" from Model import * """
from View import AnnualForecastScreen


AnnualForecastScreen.TestMethod()